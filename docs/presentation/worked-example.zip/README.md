# Recorded synthetic ObjectDNA bracket

Source main3809e47e6d3c6efc4be4ec457c1075d81f5db59f; Python3.12.13/CadQuery2.6.1.

This synthetic public example has known mm scale. Edited width90mm is user intent, not a scan measurement.
Install the repository tested dependencies, then in this fresh extracted directory run:

    python edited-bracket.py

This emits objectdna.step and objectdna.stl exclusively. Reopen with CadQuery importers.importStep.
The downloaded original is edited-bracket.step; export-check.json records its actual reopen.
With installed current ObjectDNA: objectdna project-open edited-project.json

Initial/edited evidence retain actual normalized points, specs, mesh and diagnostics.
The data-only project retains normalized points/history, not original scan bytes.
No physical accuracy or fabrication-readiness claim. Original source/synthetic assets MIT.
CadQuery/OpenCascade retain upstream licenses. See the complete repository's LICENSE and docs/UPSTREAM_LICENSES.md.
